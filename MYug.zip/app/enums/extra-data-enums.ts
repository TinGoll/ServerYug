export enum ExtraDataType {
    NUMBER = 'number',
    TEXT = 'text',
    DATE = 'date',
    SELECT = 'select'
}