const secretKey = 'Massive Yug';

export default {
    secretKey
}