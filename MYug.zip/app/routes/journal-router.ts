import { Router } from 'express';

const router = Router();
/**----------------------------- */
const prefix: string = '/journals';
// Гет запросы
router.get('/test');
router.get('/test');
router.get('/test');
router.get('/test');
router.get('/test');
router.get('/test');
router.get('/test');
router.get('/test');
router.get('/test');
router.get('/test');
router.get('/test');
router.get('/test');
router.get('/test');

// Пост запросы
router.post('/test');
router.post('/test');
router.post('/test');
router.post('/test');
router.post('/test');
router.post('/test');
router.post('/test');
router.post('/test');
router.post('/test');

// Делит запросы
router.delete('/test');
router.delete('/test');
router.delete('/test');
router.delete('/test');
router.delete('/test');

/**----------------------------- */
export default router;
