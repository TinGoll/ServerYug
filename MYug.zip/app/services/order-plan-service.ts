class OrderPlanService {
   
}

export default new OrderPlanService();