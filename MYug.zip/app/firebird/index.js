"use strict";
/*
import Firebird from "./Firebird";

export enum Base {
    CUBIC   = 'CUBIC_DB.FDB',
    ITM     = 'ITM_DB.FDB'
}
export default Firebird;

*/ 
