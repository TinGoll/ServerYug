import users from './users';
import jfunction from './virtualJournalsFun';
import atfunction from './atOrderFun';
import links from './links';


export default {
    users,
    jfunction,
    atfunction,
    links
}