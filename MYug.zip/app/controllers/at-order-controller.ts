import { NextFunction, Request, Response } from "express";


class AtOrderController {
    async getBarcodes (req: Request, res: Response, next: NextFunction) {
        try {
            
        } catch (e) {
            next(e);
        }
    }
    async getJournalNames (req: Request, res: Response, next: NextFunction) {
        try {
            
        } catch (e) {
            next(e);
        }
    }
    async getSalaryTransactionToIdJournal (req: Request, res: Response, next: NextFunction) {
        try {
            
        } catch (e) {
            next(e);
        }
    }
    async getSalaryReportToId (req: Request, res: Response, next: NextFunction) {
        try {
            
        } catch (e) {
            next(e);
        }
    }
    async getPreliminaryCalculationToIdJournal (req:Request, res: Response, next: NextFunction) {
        try {
            
        } catch (e) {
            next(e);
        }
    }
    async addOrdersToJournal (req:Request, res: Response, next: NextFunction) {
        try {
            
        } catch (e) {
            next(e);
        }
    }
    async closeBillingPeriod (req:Request, res: Response, next: NextFunction) {
        try {
            
        } catch (e) {
            next(e);
        }
    }
}
export default new AtOrderController();