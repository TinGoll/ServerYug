const orderdata = require('./orderData');

module.exports = {
    orderdata
}