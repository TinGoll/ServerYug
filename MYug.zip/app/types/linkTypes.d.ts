export declare interface Link {
     link: string;                          
     status: number;
     permission?: string;
     description?: string;
}