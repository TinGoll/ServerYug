export declare interface QueryOptions {
    $first?: any;
    $skip?: any;
    $where?: any;
    $sort?: any;
}