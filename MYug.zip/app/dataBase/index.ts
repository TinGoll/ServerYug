import { executeRequest, formatDateToDb } from './dataBase';

export default {
    executeRequest,
    formatDateToDb,
};